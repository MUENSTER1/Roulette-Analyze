# Streamlit Roulette Analyzer

Upload an image of roulette results and get bankroll tracking, heatmap, and performance metrics.