import streamlit as st
import easyocr
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from collections import Counter
import pandas as pd

reader = easyocr.Reader(['en'], gpu=False)

def process_image(uploaded_file):
    image_data = uploaded_file.read()
    np_arr = np.frombuffer(image_data, np.uint8)
    import cv2
    img = cv2.imdecode(np_arr, cv2.IMREAD_COLOR)
    results = reader.readtext(img)
    numbers = []
    for _, text, _ in results:
        cleaned = ''.join(filter(str.isdigit, text))
        if cleaned.isdigit():
            n = int(cleaned)
            if 0 <= n <= 36:
                numbers.append(n)
    return numbers, img

class BankrollManager:
    def __init__(self, initial=100):
        self.initial = initial
        self.current = initial
        self.history = [initial]

    def update(self, spins):
        for spin in spins:
            if spin % 2 == 0:
                self.current += 11
            else:
                self.current -= 1
            self.history.append(self.current)

    def summary(self):
        final = self.current
        roi = ((final - self.initial) / self.initial) * 100
        return {
            "Start": self.initial,
            "End": final,
            "ROI (%)": round(roi, 2)
        }

def metrics_report(spins, bankroll_history):
    report = {}
    counts = Counter(spins)
    report["Top Numbers"] = counts.most_common(5)

    peak = bankroll_history[0]
    max_drawdown = 0
    for value in bankroll_history:
        peak = max(peak, value)
        drawdown = peak - value
        max_drawdown = max(max_drawdown, drawdown)
    report["Max Drawdown"] = max_drawdown

    roi = ((bankroll_history[-1] - bankroll_history[0]) / bankroll_history[0]) * 100
    changes = np.diff(bankroll_history)
    volatility = np.std(changes)
    report["Volatility"] = round(volatility, 2)
    report["Sharpe Ratio"] = round((roi / volatility), 2) if volatility else "N/A"
    return report

def plot_heatmap(spins):
    counts = Counter(spins)
    matrix = np.zeros((3, 12))
    for n, count in counts.items():
        row = n // 12
        col = n % 12
        matrix[row][col] = count
    fig, ax = plt.subplots(figsize=(10, 3))
    sns.heatmap(matrix, annot=True, cmap="YlOrRd", cbar=True, ax=ax)
    st.pyplot(fig)

st.title("Roulette Spin Analyzer")

uploaded_file = st.file_uploader("Upload Spin Image", type=["jpg", "png", "jpeg"])
if uploaded_file:
    spins, img = process_image(uploaded_file)
    st.image(img, caption="Uploaded Spin Image")
    st.write("Detected Spins:", spins)

    bankroll = BankrollManager()
    bankroll.update(spins)

    st.line_chart(bankroll.history)
    st.write("Bankroll Summary:", bankroll.summary())

    st.subheader("Spin Heatmap")
    plot_heatmap(spins)

    st.subheader("Advanced Metrics")
    metrics = metrics_report(spins, bankroll.history)
    for k, v in metrics.items():
        st.write(f"{k}: {v}")

    st.subheader("Export Spin History")
    df = pd.DataFrame({
        "Spin #": list(range(len(bankroll.history))),
        "Bankroll": bankroll.history
    })
    csv = df.to_csv(index=False).encode('utf-8')
    st.download_button("Download CSV", csv, "spin_history.csv", "text/csv")
